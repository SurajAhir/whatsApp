package com.example.whatsapp.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.whatsapp.ChatDetail;
import com.example.whatsapp.Models.Users;
import com.example.whatsapp.R;
import com.example.whatsapp.ShowImage;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Chat_Adapter extends RecyclerView.Adapter<Chat_Adapter.Chat_ViewHolder> {
    List<Users> list;
    Context context;

    public Chat_Adapter(List<Users> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public Chat_ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.chat_sample_layout, parent, false);
        return new Chat_ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Chat_ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Users users = list.get(position);
        Picasso.get().load(list.get(position).getPic()).placeholder(R.drawable.person).into(holder.chat_profile_image);
        if(list.get(position).getUser_name()!= ""){
        holder.chat_username.setText(list.get(position).getUser_name());}
        else{
            holder.chat_username.setText(list.get(position).getPhoneNum());
        }
        FirebaseDatabase.getInstance().getReference().child("Chats").child(FirebaseAuth.getInstance()
                .getUid() + users.getUid()).orderByChild("timestamp").limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChildren()) {
                    for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                        holder.chat_lastmessage.setText(snapshot1.child("message").getValue(String.class));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        holder.chat_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ChatDetail.class);
                intent.putExtra("userImage", list.get(position).getPic());
                intent.putExtra("userName", list.get(position).getUser_name());
                intent.putExtra("uid", list.get(position).getUid());
                context.startActivity(intent);
            }
        });
        holder.chat_profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ShowImage.class);
                intent.putExtra("userImage", list.get(position).getPic());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class Chat_ViewHolder extends RecyclerView.ViewHolder {
        ImageView chat_profile_image;
        TextView chat_username, chat_lastmessage;
LinearLayout chat_layout;
        public Chat_ViewHolder(@NonNull View itemView) {
            super(itemView);
            chat_profile_image = itemView.findViewById(R.id.chat_profile_image);
            chat_username = itemView.findViewById(R.id.chat_username);
            chat_lastmessage = itemView.findViewById(R.id.chat_lastmessage);
            chat_layout=itemView.findViewById(R.id.chat_layout);
        }

    }
}

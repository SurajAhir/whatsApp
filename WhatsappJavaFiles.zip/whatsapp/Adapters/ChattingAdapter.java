package com.example.whatsapp.Adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.whatsapp.Models.MessageModel;
import com.example.whatsapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class ChattingAdapter extends RecyclerView.Adapter{
List<MessageModel> list;
Context context;
String receiveId;
final int SendViewType=1;
final int ReceiveVeiwType=2;
    public ChattingAdapter(List<MessageModel> list, Context context,String receiveId) {
        this.list = list;
        this.context = context;
        this.receiveId=receiveId;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if(viewType==SendViewType){
            View view= LayoutInflater.from(context).inflate(R.layout.send_layout,parent,false);
            return new SendViewHolder(view);
        }else {
            View view=LayoutInflater.from(context).inflate(R.layout.receive_layout,parent,false);
            return new ReceiveViewHolder(view);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        MessageModel model=list.get(position);
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                new AlertDialog.Builder(context).setTitle("Delete").setMessage("Are you sure you want to delete this message").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        FirebaseDatabase.getInstance().getReference().child("Chats").child(FirebaseAuth.getInstance().
                                getUid()+receiveId).child(list.get(position).getMessageId()).setValue(null);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).show();

                return true;
            }
        });
if(holder.getClass()==SendViewHolder.class){
    ((SendViewHolder)holder).send_message.setText(list.get(position).getMessage());
    ((SendViewHolder)holder).send_time.setText(list.get(position).getTimestamp());

}else {
    ((ReceiveViewHolder)holder).receive_message.setText(list.get(position).getMessage());
    ((ReceiveViewHolder)holder).receive_time.setText(list.get(position).getTimestamp());
}
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public int getItemViewType(int position) {
        if(list.get(position).getUid().equals(FirebaseAuth.getInstance().getUid())){
            Log.d("TAG","this is sender");
            return SendViewType;

        }else {
            Log.d("TAG","this is receiver");
            return ReceiveVeiwType;
        }

    }

    class SendViewHolder extends RecyclerView.ViewHolder {
        TextView send_message,send_time;
        public SendViewHolder(@NonNull View itemView) {
            super(itemView);
            send_message=itemView.findViewById(R.id.tv_send_message);
            send_time=itemView.findViewById(R.id.tv_send_time);
        }
    }
    class ReceiveViewHolder extends  RecyclerView.ViewHolder {
        TextView receive_message,receive_time;
        public ReceiveViewHolder(@NonNull View itemView) {
            super(itemView);
            receive_message=itemView.findViewById(R.id.tv_receive_message);
            receive_time=itemView.findViewById(R.id.tv_receive_time);
        }
    }
}

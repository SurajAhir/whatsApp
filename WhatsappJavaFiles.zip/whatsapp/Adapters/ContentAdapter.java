package com.example.whatsapp.Adapters;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.whatsapp.Fragments.Call;
import com.example.whatsapp.Fragments.Chat;
import com.example.whatsapp.Fragments.Status;

public class ContentAdapter extends FragmentPagerAdapter {
    public ContentAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:return new Chat();
//            case 1:return new Status();
//            case 2:return new Call();
            default:return new Chat();
        }
    }

    @Override
    public int getCount() {
        return 1;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title=null;
        switch (position){
            case 0:
                title="Chat";
                break;
//            case 1:
//                title="Status";
//                break;
//            case 2:
//                title="Call";
//                break;
//            default:title="Chat";

        }
        return title;
    }
}

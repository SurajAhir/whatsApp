package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.example.whatsapp.Adapters.ChattingAdapter;
import com.example.whatsapp.Models.MessageModel;
import com.example.whatsapp.databinding.ActivityChatDetailBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ChatDetail extends AppCompatActivity {
    ActivityChatDetailBinding binding;
    FirebaseAuth firebaseAuth;
    FirebaseDatabase firebaseDatabase;
    List<MessageModel> list;
    RecyclerView recyclerView;
    String chatSendNode,receiveUid,pic,sendUid,chatReceiveNode,userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChatDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(findViewById(R.id.chat_detail_toolbar));
       initialize();
        ChattingAdapter adapter = new ChattingAdapter(list, this, receiveUid);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        firebaseDatabase.getReference().child("Chats").child(chatSendNode).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    MessageModel model = snapshot1.getValue(MessageModel.class);
                    model.setMessageId(snapshot1.getKey());
                    list.add(model);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        Picasso.get().load(pic).placeholder(R.drawable.person).into(binding.chatDetailUserImage);
        binding.chatDetailBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ChatDetail.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        binding.chatDetailSendMessage.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                list.clear();
                if (binding.chatDetailMessage.getText().toString().isEmpty()) {
                    return;
                } else {
                    String message = binding.chatDetailMessage.getText().toString();
                    MessageModel model = new MessageModel();
                    model.setUid(firebaseAuth.getCurrentUser().getUid());
//                    model.setTimestamp(new Date().getTime());
                    Calendar now = Calendar.getInstance();
                    int hour = now.get(Calendar.HOUR);
                    int minute = now.get(Calendar.MINUTE);
                    String timestamp = hour + ":" + minute;
                    model.setTimestamp(timestamp);
                    model.setMessage(binding.chatDetailMessage.getText().toString());
                    list.add(model);
                    firebaseDatabase.getReference().child("Chats").child(chatSendNode).push().setValue(model);
                    firebaseDatabase.getReference().child("Chats").child(chatReceiveNode).push().setValue(model);
                    binding.chatDetailMessage.setText("");
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void initialize() {
        recyclerView = findViewById(R.id.recyclerview);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
         userName = getIntent().getStringExtra("userName");
         pic = getIntent().getStringExtra("userImage");
         receiveUid = getIntent().getStringExtra("uid");
        sendUid = firebaseAuth.getCurrentUser().getUid();
        chatSendNode = sendUid + receiveUid;
         chatReceiveNode = receiveUid + sendUid;
        binding.chatDetailUserName.setText(userName);
        list = new ArrayList<>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu2,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.clear_chat:
                firebaseDatabase.getReference().child("Chats").child(chatSendNode).setValue(null);
                break;
        }
        return true;
    }
}
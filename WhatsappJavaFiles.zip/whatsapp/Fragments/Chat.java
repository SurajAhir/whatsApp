package com.example.whatsapp.Fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.whatsapp.Adapters.Chat_Adapter;
import com.example.whatsapp.MainActivity;
import com.example.whatsapp.Models.Users;
import com.example.whatsapp.R;
import com.example.whatsapp.databinding.FragmentChatBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Chat extends Fragment {
    List<Users> list;
    HashMap<String, String> arrayList;
    TreeMap<String, String> arrayListname;
    RecyclerView recyclerView;
    FirebaseAuth firebaseAuth;
    FirebaseDatabase firebaseDatabase;
    FragmentChatBinding binding;
    Chat_Adapter chat_adapter;
    FirebaseUser firebaseUser;

    public Chat() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChatBinding.inflate(inflater, container, false);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        checkPermission();
        firebaseUser = firebaseAuth.getCurrentUser();
        list = new ArrayList<>();
        chat_adapter = new Chat_Adapter(list, getContext());
        binding.chatRecyclerview.setAdapter(chat_adapter);
        binding.chatRecyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        return binding.getRoot();
    }

    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_CONTACTS}, 100);
        } else {
            getContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getContacts();
        } else {
            Toast.makeText(getContext(), "Permission Denied!", Toast.LENGTH_SHORT).show();
            checkPermission();
        }
    }

    private void getContacts() {
        arrayList = new HashMap<>();
        arrayListname = new TreeMap<>();
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String phone = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            if (phone.startsWith("+91")) {
                arrayList.put(phone.replaceAll(" ", ""), name);
            } else {
                arrayList.put("+91" + phone.replaceAll(" ", ""), name);
            }


        }
        Set st = arrayList.entrySet();
        Iterator it = st.iterator();
        while (it.hasNext()) {
            Log.d("aho", it.next() + "");
        }
        firebaseDatabase.getReference().child("UserPhoneNumbers").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    Users users = snapshot1.getValue(Users.class);
//                    Log.d("phone",users.getPhoneNum());
                    if (firebaseUser.getUid().equals(users.getUid())) {
                        continue;
                    } else {
                        Set st = arrayList.entrySet();
                        Iterator it = st.iterator();
                        while (it.hasNext()) {
//                            Log.d("phone",users.getPhoneNum());
                            Map.Entry mp = (Map.Entry) it.next();
                            String num = mp.getKey().toString();
                            String name = mp.getValue().toString();
                            if (num.equals(users.getPhoneNum())) {
                                users.setPhoneNum(num);
//                                Log.d("phone",users.getPhoneNum());
                                users.setUser_name(name);

                                list.add(users);
                            }

                        }

                    }
                }
                chat_adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

    }

}
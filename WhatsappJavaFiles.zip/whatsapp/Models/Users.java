package com.example.whatsapp.Models;

public class Users {
    String pic,user_name,user_id,user_password,lastmessage,uid,phoneNum,status;

    public Users(String pic, String user_name, String user_id, String user_password, String lastmessage,String uid,String phoneNum) {
        this.pic = pic;
        this.user_name = user_name;
        this.user_id = user_id;
        this.user_password = user_password;
        this.lastmessage = lastmessage;
        this.uid=uid;
        this.phoneNum=phoneNum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Users(String user_name, String user_id, String user_password) {
        this.user_name = user_name;
        this.user_id = user_id;
        this.user_password = user_password;
    }
public Users(){}
    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getLastmessage() {
        return lastmessage;
    }

    public void setLastmessage(String lastmessage) {
        this.lastmessage = lastmessage;
    }
}

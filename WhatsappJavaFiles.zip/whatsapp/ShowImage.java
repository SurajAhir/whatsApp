package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class ShowImage extends AppCompatActivity {
ImageView imageView;
Button backArrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_image);
        imageView=findViewById(R.id.imageView);
        backArrow=findViewById(R.id.show_user_image_back_arrow);
        String image=getIntent().getStringExtra("userImage");
        Picasso.get().load(image).placeholder(R.drawable.person).into(imageView);
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ShowImage.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

}
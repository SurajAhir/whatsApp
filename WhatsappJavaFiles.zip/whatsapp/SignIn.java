package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.whatsapp.databinding.ActivitySignInBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignIn extends AppCompatActivity {
ActivitySignInBinding binding;
FirebaseAuth firebaseAuth;
    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivitySignInBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dialog=new ProgressDialog(this);
        dialog.setMessage("wait....");
        firebaseAuth=FirebaseAuth.getInstance();
        SharedPreferences pre=getSharedPreferences("demo",MODE_PRIVATE);
        boolean value=pre.getBoolean("value",false);
        if(value){
            Intent intent=new Intent(SignIn.this,MainActivity.class);
            startActivity(intent);
            finish();
        }
        binding.signin.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                if(binding.userId.getText().toString().isEmpty()){
                    binding.userId.setError("Field Required");
                    binding.userId.setFocusable(View.FOCUSABLE);
                }
                if(binding.userPassword.getText().toString().isEmpty()){
                    binding.userPassword.setError("Field Required");
                    binding.userPassword.setFocusable(View.FOCUSABLE);
                }
                else{
                    dialog.show();
                        firebaseAuth.signInWithEmailAndPassword(binding.userId.getText().toString(),
                        binding.userPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            dialog.dismiss();
                            Intent intent=new Intent(SignIn.this,MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                        else {
                            Toast.makeText(SignIn.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }}
        });
        binding.create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SignIn.this,SignUp.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
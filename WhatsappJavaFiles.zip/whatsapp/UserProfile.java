package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.Toast;

import com.example.whatsapp.Models.Users;
import com.example.whatsapp.databinding.ActivityUserProfileBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class UserProfile extends AppCompatActivity {
    ActivityUserProfileBinding binding;
    FirebaseDatabase firebaseDatabase;
    FirebaseStorage firebaseStorage;
    FirebaseAuth firebaseAuth;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize();
        showProfileImage();
        binding.save.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                if (binding.profileUsername.getText().toString().isEmpty()) {
                    binding.profileUsername.setError("Field Required");
                    binding.profileUsername.setFocusable(View.FOCUSABLE);
                } else if (binding.profileStatus.getText().toString().isEmpty()) {
                    binding.profileStatus.setError("Field Required");
                    binding.profileStatus.setFocusable(View.FOCUSABLE);
                } else {
                    progressDialog.show();
                    String userName = binding.profileUsername.getText().toString();
                    String status = binding.profileStatus.getText().toString();
                    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
                    String uid = firebaseAuth.getCurrentUser().getUid();
                    HashMap<String, Object> hashMap = new HashMap<>();
                    hashMap.put("user_name", userName);
                    hashMap.put("status", status);
                    firebaseDatabase.getReference().child("Users").child(uid).updateChildren(hashMap);
                    firebaseDatabase.getReference().child("UserPhoneNumbers").child(uid).updateChildren(hashMap);
                    Toast.makeText(UserProfile.this, "Details Saved", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
        });
        binding.addImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dexter.withContext(UserProfile.this).withPermission(Manifest.permission.READ_EXTERNAL_STORAGE).withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        addImage();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                }).check();

            }
        });
        binding.userProfileBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(UserProfile.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void showProfileImage() {
        firebaseDatabase.getReference().child("UserPhoneNumbers").child(firebaseAuth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Users users = snapshot.getValue(Users.class);
                Picasso.get().load(users.getPic()).placeholder(R.drawable.person).into(binding.userImage);
                binding.profileUsername.setText(users.getUser_name());
                binding.profileStatus.setText(users.getStatus());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UserProfile.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private void initialize() {
        SharedPreferences pre = getSharedPreferences("demo", MODE_PRIVATE);
        SharedPreferences.Editor editor = pre.edit();
        editor.putBoolean("value", true);
        editor.commit();
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
    }

    private void addImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, 1001);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(UserProfile.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001) {
            Uri uri1 = data.getData();
            binding.userImage.setImageURI(uri1);
            StorageReference reference = firebaseStorage.getReference().child("Images");
            reference.putFile(uri1).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                    reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(@NonNull Uri uri) {
                            firebaseDatabase.getReference().child("Users").child(firebaseAuth.getCurrentUser().getUid()).child("pic").setValue(uri.toString());
                            firebaseDatabase.getReference().child("UserPhoneNumbers").child(firebaseAuth.getCurrentUser().getUid()).child("pic").setValue(uri.toString());
                            Toast.makeText(UserProfile.this, "Image Updated Successfully", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }
    }

}